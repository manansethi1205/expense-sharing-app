# Final recruiter submission

Start with [SUBMISSION.md](SUBMISSION.md) for links, the five-minute walkthrough and assignment coverage.

- [Setup Instructions](output/pdf/setup-instructions.pdf)
- [API Documentation](output/pdf/api-documentation.pdf)
- [Database Schema Explanation](output/pdf/database-schema-explanation.pdf)
- [Postman collection](docs/expense-sharing.postman_collection.json)
- [Render Postman environment](docs/Render.postman_environment.json)
- [Local Postman environment](docs/Local.postman_environment.json)
- [Deployment guide](docs/render.md)
- [Verification record](docs/verification.md)

Live demo: https://expense-sharing-app-inda.onrender.com/
Source: https://github.com/manansethi1205/expense-sharing-app

This archive contains documentation and review artifacts. Clone the source repository to run the full project; application source/dependencies are not duplicated in this document bundle. The .env.example contains synthetic local defaults, not hosted credentials. MANIFEST.json records file hashes and the application baseline. No real .env file, credential, database, log or cache is included.
